/**
 * 
 */
package com.library.project.constants;

/**
 * @author darshanbidkar
 * 
 */
public class LibraryButtons {

	public static final String BTN_SEARCH = "Search";

}
