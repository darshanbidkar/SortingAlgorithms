/**
 * 
 */
package com.library.project.constants;

/**
 * @author darshanbidkar
 * 
 */
public class LibraryConstants {

	public static String DATABASE_PATH = "jdbc:mysql://localhost/library?user=root&password=";
	public static String DATABSE_DRIVER = "com.mysql.jdbc.Driver";

}
